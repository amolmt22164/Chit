const express = require('express');
const router = express.Router();
const Student = require('../models/Student');

// 🔹 Move this middleware to the top BEFORE routes that use it
const getStudent = async (req, res, next) => {
    try {
        const student = await Student.findById(req.params.id);
        if (!student) return res.status(404).json({ message: 'Student not found' });
        res.student = student;
        next();
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// Get all students
router.get('/', async (req, res) => {
    try {
        const students = await Student.find();
        res.json(students);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Get a single student by ID
router.get('/:id', getStudent, (req, res) => {
    res.json(res.student);
});

// Create a new student
router.post('/', async (req, res) => {
    const { name, email, course } = req.body;
    const student = new Student({ name, email, course });
    try {
        const newStudent = await student.save();
        res.status(201).json(newStudent);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Update a student
router.patch('/:id', getStudent, async (req, res) => {
    Object.assign(res.student, req.body);
    try {
        const updatedStudent = await res.student.save();
        res.json(updatedStudent);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Delete a student
router.delete('/:id', getStudent, async (req, res) => {
    try {
        await res.student.deleteOne();
        res.json({ message: 'Deleted Student' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;
